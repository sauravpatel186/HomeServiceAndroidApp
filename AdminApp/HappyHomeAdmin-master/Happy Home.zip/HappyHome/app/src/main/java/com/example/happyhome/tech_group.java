package com.example.happyhome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class tech_group extends AppCompatActivity implements View.OnClickListener {
    ImageButton tech1,tech2,tech3,tech4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tech_group);
        tech1=findViewById(R.id.tech1);
        tech2=findViewById(R.id.tech2);
        tech3=findViewById(R.id.tech3);
        tech4=findViewById(R.id.tech4);
        tech1.setOnClickListener(this);
        tech2.setOnClickListener(this);
        tech3.setOnClickListener(this);
        tech4.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i=new Intent(tech_group.this,tech_detail.class);
        startActivity(i);
    }
}
